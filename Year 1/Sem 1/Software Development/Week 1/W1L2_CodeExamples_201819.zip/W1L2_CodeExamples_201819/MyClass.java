/**
 * A minimal Java program.
 * @author Michael Lones, Heriot-Watt University
 */

public class MyClass {
	public static void main(String[] args) {

	}
}