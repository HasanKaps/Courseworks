/**
 * Hello World in Java.
 * @author Michael Lones, Heriot-Watt University
 */

public class HelloWorld {
	public static void main(String[] a){
		System.out.println("Hello World");
	} 
}
