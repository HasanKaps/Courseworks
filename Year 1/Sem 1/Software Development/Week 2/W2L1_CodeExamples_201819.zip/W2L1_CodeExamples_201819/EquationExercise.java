/**
 * Exercise: complete the missing code (see W2W1 slide).
 * @author Michael Lones, Heriot-Watt University
 */
public class EquationExercise {

	public static void main(String[] args) {
		double x = 10.5, a = 2.5, b = 10;
		double y = // missing code goes here
		System.out.println("y="+y);
	}

}
