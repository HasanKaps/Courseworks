/**
 * Simple demonstration of declaring and printing strings.
 * @author Michael Lones, Heriot-Watt University
 */
public class StringDemo {

	public static void main(String[] args) {
		String name = "Bob";
		int age = 18;
		System.out.println("My name is " + name + ". I am " + age + ".");
	}

}
