/**
 * An illustration of how types can be problematic in expressions
 * @author Michael Lones, Heriot-Watt University
 */
public class ProblemEquation {

  public static void main(String[] args) {
    int a = 1;
    int b = 2;
    double c = a / b;
    System.out.println(c);
  }

}
