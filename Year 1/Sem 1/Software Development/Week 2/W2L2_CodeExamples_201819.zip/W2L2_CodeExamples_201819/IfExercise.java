/**
 * Exercise: complete the if condition so that aubergines
 * are correctly identified (they are 5-15cm, neither
 * yellow nor red, and are not square).
 * @author Michael Lones, Heriot-Watt University
 */

public class IfExercise {
	public static void main(String[] args) {
		double size = 10;
		boolean yellow = false, red = false;
		boolean square = false;
		if() // add code here
			System.out.println("Aubergine!");
	}
}
