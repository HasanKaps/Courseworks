/**
 * Showing the return value of a Boolean operator
 * @author Michael Lones, Heriot-Watt University
 */
public class IntCompare {

	public static void main(String[] args) {
		int a = 5;
		int b = 5;
		System.out.println( a == b );
	}

}
