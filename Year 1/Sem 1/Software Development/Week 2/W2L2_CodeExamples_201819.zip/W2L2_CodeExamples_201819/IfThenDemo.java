/**
 * Simple demonstration of if statement.
 * @author Michael Lones, Heriot-Watt University
 */
public class IfThenDemo {

	public static void main(String[] args) {
		int age = 18;
		if(age > 40) {
			System.out.println("You're old!");
			System.out.println("I respect you.");
		}
	}

}
