/**
 * Simple demonstration of if...else statement.
 * @author Michael Lones, Heriot-Watt University
 */
public class IfThenElseDemo {

	public static void main(String[] args) {
		int age = 18;
		if(age > 40)
			System.out.println("You're old!");
		else
			System.out.println("You're young!");
	}

}
