/**
 * Simple demonstration of a while loop.
 * @author Michael Lones, Heriot-Watt University
 */
public class WhileDemo {
	
	public static void main(String[] args) {
		String message = "Hello!";
		while(true) {
			System.out.println(message);
		}
	}
	
}
