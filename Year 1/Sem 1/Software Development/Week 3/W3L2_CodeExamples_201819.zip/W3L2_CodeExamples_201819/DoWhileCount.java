/**
 * Simple demonstration of a do...while loop.
 * @author Michael Lones, Heriot-Watt University
 */
public class DoWhileCount {

	public static void main(String[] args) {
		int count = 0;
		do {
			count++;
			System.out.print(count+" ");
		} while(count<20);
	}

}
