/**
 * Simple demonstration of a for loop.
 * @author Michael Lones, Heriot-Watt University
 */
public class ForCount {

	public static void main(String[] args) {
		for(int count=0; count<=20; count++) {
			System.out.print(count+" ");
		}
	}

}
