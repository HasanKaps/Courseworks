import java.util.Scanner;

/**
 * Demonstration of initialising, using and printing an array.
 * @author Michael Lones, Heriot-Watt University
 */
public class ArrayDemo2 {

	public static void main(String[] args) {
		int[] scores = new int[10];
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Please input scores:");
		for(int i=0; i<scores.length; i++)
			scores[i] = scan.nextInt();
		
		System.out.println("The scores for Lab 2 were:");
		for(int i=0; i<10; i++) {
			System.out.print(scores[i] + " ");
		}
	}

}
