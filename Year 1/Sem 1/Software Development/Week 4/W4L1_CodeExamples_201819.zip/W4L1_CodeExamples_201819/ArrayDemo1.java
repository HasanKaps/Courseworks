/**
 * Simple demonstration of using and printing an array.
 * @author Michael Lones, Heriot-Watt University
 */
public class ArrayDemo1 {

	public static void main(String[] args) {
		int[] scores = {5,7,5,8,2,8,0,4,6,7};
		System.out.println("The scores for Lab 2 were:");
		for(int i=0; i<10; i++) {
			System.out.print(scores[i] + " ");
		}
	}

}
