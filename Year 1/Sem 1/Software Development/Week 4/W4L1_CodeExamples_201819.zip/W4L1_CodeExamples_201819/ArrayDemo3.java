import java.util.Scanner;

/**
 * Calculates the average of a series of lab scores enter by the user.
 * @author Michael Lones, Heriot-Watt University
 */
public class ArrayDemo3 {

	public static void main(String[] args) {
		int[] scores = new int[10];
		int sum = 0; // sum of scores
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Please input scores:");
		for(int i=0; i<scores.length; i++)
			scores[i] = scan.nextInt();
		
		// calculate sum of scores
		for(int i=0; i<scores.length; i++)
			sum += scores[i];
		
		// calculate and display average
		System.out.println("Average:"+ (sum/scores.length));
	}

}
