import java.util.Scanner;

/**
 * This program analyses student labs scores.
 * It calculates the mean scores for each lab and student.
 * @author Michael Lones, Heriot-Watt University
 */
public class LabsScoreAnalysis {
	public static void main(String[] args) {
		double scores[][]; // lab scores
		int labs;		   // number of labs
		int students;      // number of students
		double lowest;     // lowest score
		double highest;    // highest score
		double mean;       // mean score
		
		// find out how many students there are
		System.out.println("How many students?");
		Scanner scan = new Scanner(System.in);
		students = scan.nextInt();
		
		// find out how many labs there are
		System.out.println("How many labs?");
		labs = scan.nextInt();
		
		// make the scores array the correct size
		scores = new double[labs][students];
		
		// read scores from user
		for(int lab=0; lab<labs; lab++) {
			System.out.println("Input scores for lab "+(lab+1)+":");
			for(int stud=0; stud<students; stud++)
				scores[lab][stud] = scan.nextDouble();
		}
		
		// find mean score for each lab
		for(int lab=0; lab<labs; lab++) {
			mean = 0;
			for(int stud=0; stud<students; stud++)
				mean += scores[lab][stud];
			mean /= students;
			System.out.println("Mean for lab "+(lab+1)+" is "+mean);
		}
		
		// find mean score for each student
		for(int stud=0; stud<students; stud++) {
			mean = 0;
			for(int lab=0; lab<labs; lab++)
				mean += scores[lab][stud];
			mean /= students;
			System.out.println("Mean for student "+(stud+1)+" is "+mean);
		}
		
	}

}
