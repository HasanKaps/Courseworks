/**
 * Simple example of using methods.
 * @author Michael Lones, Heriot-Watt University
 */
public class SubprogramDemo2 {
	
	public static void main(String[] args) {
		countup();
		countup();
	}
	
	static void countup() {
		for(int i=1; i<=10; i++)
			System.out.print(i+" ");
	}
	
}
