/**
 * Simple example of using methods.
 * @author Michael Lones, Heriot-Watt University
 */
public class CalculateHypotenuse {

	public static void main(String[] args) {
		System.out.println( pythagoras(5, 10) );
	}
	
	/*
	 *  This method returns the square of its argument.
	 */
	static double square(double arg) {
		return arg * arg;
	}
	
	/*
	 * This method applied Pythagoras's theorem to its arguments.
	 */
	static double pythagoras(double a, double b) {
		double val = square(a) + square(b);
		return Math.sqrt(val);
	} 

}
