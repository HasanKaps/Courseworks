/**
 * Simple example of using methods.
 * @author Michael Lones, Heriot-Watt University
 */
public class SubprogramDemo4 {
	
	public static void main(String[] args) {
		count(5,43,3);
	}
	
	static void count(int from, int to, int step) {
		for(int i=from; i<=to; i+=step)
			System.out.print(i+" ");
	}
	
}
