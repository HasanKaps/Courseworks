/**
 * Simple example of using methods.
 * @author Michael Lones, Heriot-Watt University
 */
public class SubprogramDemo3c {
	
	public static void main(String[] args) {
		countup(2); 
		countup(4);
		countup(6);
		countup(8);
	}
	
	static void countup(int to) {
		for(int i=1; i<=to; i++)
			System.out.print(i+" ");
	}
	
}
