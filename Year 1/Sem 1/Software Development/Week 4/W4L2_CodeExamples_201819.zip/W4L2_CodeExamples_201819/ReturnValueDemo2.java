/**
 * Another simple example of using return values.
 * @author Michael Lones, Heriot-Watt University
 */
public class ReturnValueDemo2 {
	
	public static void main(String[] args) {
		System.out.println( max(2,4) );
	}
	
	/*
	 *  This method returns the largest of its two argument.
	 */
	static double max(double arg1, double arg2) {
		if(arg1>arg2)
			return arg1;
		else
			return arg2;
	} 
}
