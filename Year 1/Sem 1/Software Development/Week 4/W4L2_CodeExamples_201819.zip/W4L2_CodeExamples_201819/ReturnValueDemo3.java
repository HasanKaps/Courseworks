/**
 * Another simple example of using return values.
 * @author Michael Lones, Heriot-Watt University
 */
public class ReturnValueDemo3 {
	
	public static void main(String[] args) {
		System.out.println( square(5) * max(2,4) );
	}
	
	/*
	 *  This method returns the square of its argument.
	 */
	static double square(double arg) {
		return arg * arg;
	}
	
	/*
	 *  This method returns the largest of its two argument.
	 */
	static double max(double arg1, double arg2) {
		if(arg1>arg2)
			return arg1;
		else
			return arg2;
	} 
}
