/**
 * A simple example of using return values.
 * @author Michael Lones, Heriot-Watt University
 */
public class ReturnValueDemo1 {
	
	public static void main(String[] args) {
		double y = square(5);
		System.out.println(y);
	}
	
	/*
	 *  This method returns the square of its argument.
	 */
	static double square(double arg) {
		double result = arg * arg;
		return result;
	}
	
}
