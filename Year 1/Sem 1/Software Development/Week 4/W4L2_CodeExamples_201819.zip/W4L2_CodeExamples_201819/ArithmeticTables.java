import java.util.Scanner;

/**
 * Displays multiplication and division tables for 
 * a given range of numbers on the terminal.
 * @author Michael Lones, Heriot-Watt University
 */
public class ArithmeticTables {

	public static void main(String[] args) {
		// variable declarations
		int maxtable; // largest table
		int maxvalue; // largest argument

		// get input from user
		Scanner scan = new Scanner(System.in);
		System.out.println("What number would you like to produce tables up to?");
		maxtable = scan.nextInt();
		System.out.println("What is the maximum argument for each table?");
		maxvalue = scan.nextInt();

		outputTables(maxtable, maxvalue); // print out tables
	}

	// output arithmetic tables
	static void outputTables(int uptotable, int uptovalue) {
		for (int table = 1; table <= uptotable; table++) {
			outputMultTable(table, uptovalue);
			outputDivisionTable(table, uptovalue);
			System.out.println();
		}
	}

	// output a single multiplication table
	static void outputMultTable(int table, int upto) {
		int product; // multiplier x multiplicand
		System.out.println("Multiplication table for " + table);
		for (int value = 1; value <= upto; value++) {
			product = table * value;
			System.out.println(table + " x " + value + " = " + product);
		}
	}

	// output a single division table
	static void outputDivisionTable(int table, int upto) {
		double quotient; // dividend / dividor
		System.out.println("Division table for " + table);
		for (int value = 1; value <= upto; value++) {
			quotient = table / (double) value;
			System.out.println(table + " / " + value + " = " + quotient);
		}
	}
}
