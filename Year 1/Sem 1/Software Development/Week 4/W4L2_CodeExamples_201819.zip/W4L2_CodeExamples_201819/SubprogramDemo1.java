/**
 * Simple example of using methods.
 * @author Michael Lones, Heriot-Watt University
 */
public class SubprogramDemo1 {
	
	public static void main(String[] args) {
		countup();
		countdown();
	}
	
	static void countup() {     // sub-program 1
		for(int i=1; i<=10; i++)
			System.out.print(i+" ");
	}
	
	static void countdown() {   // sub-program 2
		for(int i=10; i>0; i--)
			System.out.print(i+" "); 
	}
	
}
