import java.util.Scanner;

/**
 * Simple example of using methods (NOTE: This is incorrect!)
 * @author Michael Lones, Heriot-Watt University
 */
public class SubprogramDemo3a {
	
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int max = scan.nextInt();
		countup();
		countup();
	}
	
	static void countup() {
		for(int i=1; i<=max; i++)
			System.out.print(i+" ");
	}
	
}
